package com.collins.stopwatchc;

import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


public class StopwatchActivity extends AppCompatActivity {
        Button buttonStart, buttonReset,buttonStop;
        TextView timer;
        private int seconds = 0;
        private boolean running=false;
        private boolean wasRunning=false;

        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_stopwatch);
            buttonStart= findViewById(R.id.start_button);
            buttonStop = findViewById(R.id.stop_button);
            buttonReset = findViewById(R.id.reset_button);
            timer = findViewById(R.id.time_view);

            //
            buttonStop.setAlpha(0);
            buttonReset.setAlpha(0);


            //import font
            Typeface MMedium = Typeface.createFromAsset(getAssets(),"fonts/MRegular.ttf");
            buttonStart.setTypeface(MMedium);
            buttonReset.setTypeface(MMedium);
            buttonStop.setTypeface(MMedium);
            buttonStart.setTypeface(MMedium);

            if (savedInstanceState!=null) {
                seconds = savedInstanceState.getInt("seconds");
                running = savedInstanceState.getBoolean("running");
                wasRunning = savedInstanceState.getBoolean("wasRunning");
            }
            runTimer();

        }



        protected void onPause(){
            super.onPause();
            wasRunning =running;
            running = false;
        }

        protected void onResume() {
            super.onResume();
            if (wasRunning) {
                running = true;
            }
        }

        @Override
        protected void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
            super.onSaveInstanceState(savedInstanceState);
            savedInstanceState.putInt("seconds", seconds);
            savedInstanceState.putBoolean("running", running);
            savedInstanceState.putBoolean("wasRunning", wasRunning);
        }

        public void onClickStart (View view){
            buttonStart.animate().alpha(0).translationY(-90).setDuration(1000);
            buttonStop.animate().alpha(1).translationY(-90).setDuration(500);
            buttonReset.animate().alpha(1).translationY(-90).setDuration(1000);

            running = true;
        }

        public void onClickStop (View view){

            running=false;
        }

        public void onClickReset (View view){
            running=false;
            seconds=0;
            buttonStart.animate().alpha(1).translationY(-90).setDuration(1000);
            buttonStop.animate().alpha(0).translationY(-90).setDuration(500);
            buttonReset.animate().alpha(0).translationY(-90).setDuration(1000);

        }
        private void runTimer() {
            final TextView timeView = (TextView) findViewById(R.id.time_view);
            final Handler handler = new Handler();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    int hours = seconds / 3600;
                    int minutes = (seconds % 3600) / 60;
                    int secs = seconds % 60;
                    String time = String.format("%d:%02d:%02d", hours, minutes, secs);
                    timeView.setText(time);
                    if (running) {
                        seconds++;
                    }
                    handler.postDelayed(this, 1000);
                }
            });
        }

    }


